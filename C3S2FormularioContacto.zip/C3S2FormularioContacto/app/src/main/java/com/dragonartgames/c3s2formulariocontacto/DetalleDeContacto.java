package com.dragonartgames.c3s2formulariocontacto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetalleDeContacto extends AppCompatActivity {

    private TextView tv_nombrecompleto, tv_fecha, tv_telefono, tv_Email, tv_Descripción;
    private Button tv_editar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_de_contacto);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Detalle de Contacto");


        tv_nombrecompleto = findViewById(R.id.tv_nombrecompleto);
        tv_fecha = findViewById(R.id.tv_fecha);
        tv_telefono=findViewById(R.id.tv_telefono);
        tv_Email = findViewById(R.id.tv_Email);
        tv_Descripción=findViewById(R.id.tv_Descripción);

        tv_editar = findViewById(R.id.tv_editar);

        Bundle bundle =  getIntent().getExtras();
        String nombreCompleto = bundle.getString("nombreCompleto");
        String fecha = bundle.getString("fecha");
        String telefono = bundle.getString("telefono");
        String mail = bundle.getString("mail");
        String  descripción = bundle.getString("descripción");

        tv_nombrecompleto.setText(nombreCompleto);
        tv_fecha.setText(fecha);
        tv_telefono.setText(telefono);
        tv_Email.setText(mail);
        tv_Descripción.setText(descripción);

        tv_editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });







    }
}
