package com.dragonartgames.c3s2formulariocontacto;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {


    private Button tvBtnFecha, tvsiguiente;
    private EditText tvNombreCompleto, tvtelefono, tvEmail, tvDescripcion;
    private DatePickerDialog.OnDateSetListener onDateSetListener;

    private int año, mes, dia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvNombreCompleto = findViewById(R.id.tvNombrecompleto);
        tvtelefono = findViewById(R.id.tvtelefono);
        tvEmail = findViewById(R.id.tvEmail);
        tvDescripcion = findViewById(R.id.tvDescripcion);

        tvBtnFecha = findViewById(R.id.tvBtnFecha);
        tvsiguiente = findViewById(R.id.tvsiguiente);

        Calendar calendar = Calendar.getInstance();

        año = calendar.get(Calendar.YEAR);
        mes = calendar.get(calendar.MONTH);
        dia = calendar.get(calendar.DAY_OF_MONTH);


        tvBtnFecha.setText(dia+"/"+(mes+1)+"/"+año);

        tvBtnFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, R.style.stilodate, onDateSetListener, año, mes, dia);
                datePickerDialog.show();
            }
        });

        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                año = i;
                mes = i1;
               dia = i2;
                tvBtnFecha.setText(dia+"/"+(mes + 1)+"/"+año);
            }
        };

        tvsiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, DetalleDeContacto.class);
                i.putExtra("nombreCompleto", tvNombreCompleto.getText().toString());
                i.putExtra("fecha", dia+"/"+(mes + 1)+"/"+año);
                i.putExtra("telefono", tvtelefono.getText().toString());
                i.putExtra("mail",   tvEmail.getText().toString());
                i.putExtra("descripción", tvDescripcion .getText().toString());

                startActivity(i);
            }
        });








    }
}
